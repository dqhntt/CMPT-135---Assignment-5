#ifndef PROGRAM_MAIN_H
#define PROGRAM_MAIN_H

int program_main();
int program_main_ncurses();

#endif // PROGRAM_MAIN_H