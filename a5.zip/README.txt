CMPT 135 Final Project
======================

Names of Team Members
---------------------
Name:             Student Number: 
Aotian Chen       301360315
Hieu Duong        301380066


Instructions for Compiling and Running
--------------------------------------
Unzip archive to folder "a5".
Under that folder, type "make" in the shell to make all the necessary files and run the program.

In the rare event that the program can't be compiled, 
a pre-compiled binary executable named "a5_main" is provided in that folder.
To run this backup, type "./a5_main" from within this folder.


Limitations
-----------
N/A


Known Bugs
----------
N/A


Extra Features
--------------
We provided options for users to choose either run in the terminal (regular mode) or ncurses mode.


References
----------
Our dataset comes from Canada Cites Database. 
Web site: 
https://simplemaps.com/data/canada-cities

